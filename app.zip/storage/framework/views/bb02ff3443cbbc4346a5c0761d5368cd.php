<?php $__env->startSection('content'); ?>

<div class="container mw-100">

<?php if(Session::get('success')): ?>
<script type="text/javascript">
    Swal.fire({
  icon: "success",
  title: "<?php echo e(Session::get('success')); ?>",
  showConfirmButton: false,
  timer: 2000
});
</script>
<?php endif; ?>
    <div class="row justify-content-center">
        <div class="col mw-100">
            <div class="card">
                <div class="card-header d-flex justify-content-between fw-bold"><?php echo e(__('Rekap Absensi Bulanan Pegawai')); ?>

                </div>
                <div class="card-body d-flex justify-content-center">
                    <div class="col-md-6 d-flex ">
                    <form id="formRekap" action="<?php echo e(route('pegawai.absensi.rekapview')); ?>" method="POST" target="_blank">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3 align-items-end">
                        <?php
                       use App\Models\PerusahaanModel;
                           $tenants = PerusahaanModel::all();
                       ?>
                       <?php if(Auth::user()->role == 0): ?>
                        
                        <div class="">
                            <label for="tenant" class="form-label">Pilih Tenant</label>
                            <select name="tenant" id="tenant" class="form-select">
                                <option value="">-- Pilih Tenant --</option>
                                <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tenan->id); ?>"><?php echo e($tenan->perusahaan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                       <?php endif; ?>

                       <?php if(Auth::user()->role == 1 || Auth::user()->role == 0): ?>
                        
                        <div class="">
                            <label for="kantor" class="form-label">Pilih Kantor</label>
                            <select name="kantor" id="kantor" class="form-select">
                                <option value="">-- Pilih Kantor --</option>
                                <?php if(Auth::user()->role != 0): ?>
                                    <?php $__currentLoopData = $kantors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kantor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($kantor->id); ?>"><?php echo e($kantor->nama_kantor); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                       <?php endif; ?>
                       
                        
                        <div class="">
                            <label for="departemen" class="form-label">Pilih Departemen</label>
                            <select name="departemen" id="departemen" class="form-select">
                                <option value="">-- Pilih Departemen --</option>
                                <?php if(Auth::user()->role == 3): ?>
                                    <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->nama_dept); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        
                        <div class="">
                            <label for="satker" class="form-label">Pilih Satker</label>
                            <select name="satker" id="satker" class="form-select">
                                <option value="">-- Pilih Satker --</option>
                            </select>
                        </div>
                        
                        <div class="">
                            <label for="periode" class="form-label mb-0">Bulan & Tahun</label>
                            <input 
                            type="month" 
                            name="periode" 
                            id="periode" 
                            class="form-control" 
                            min="<?php echo e(Carbon\Carbon::parse($tabul->created_at)->format('Y-m')); ?>"
                            max="<?php echo e(now()->format('Y-m')); ?>" 
                            value="<?php echo e(now()->format('Y-m')); ?>">
                        </div>

                        
                        <div class="d-flex justify-content-around">
                            <button type="submit" name="action" value="cetak" class="btn btn-primary">
                                <i class="bi bi-printer"></i> Cetak
                            </button>

                            <button type="submit" name="action" value="excel" class="btn btn-success">
                                <i class="bi bi-download"></i> Export to Excel
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
        <?php if(Auth::user()->role == 0): ?>
        // Load Departemen saat Kantor dipilih
    $('#tenant').on('change', function () {
        let tenanrId = $(this).val();
        $('#kantor').empty().append('<option value="">-- Pilih Kantor --</option>');
        $('#departemen').empty().append('<option value="">-- Pilih Departemen --</option>');
        $('#satker').empty().append('<option value="">-- Pilih Satker --</option>');
        $('#pegawais').empty().append('<option value="">-- Pilih Karyawan --</option>');

        if (tenanrId) {
            $.get('/get-konten/' + tenanrId, function (data) {
                data.offices.forEach(function (kant) {
                    $('#kantor').append('<option value="' + kant.id + '">' + kant.nama_kantor + '</option>');
                });
            });
        }
    });    
    <?php endif; ?>
    
    <?php if(Auth::user()->role == 1 || Auth::user()->role == 0): ?>
        // Load Departemen saat Kantor dipilih
        $('#kantor').on('change', function () {
            let kantorId = $(this).val();
            $('#departemen').empty().append('<option value="">-- Pilih Departemen --</option>');
            $('#satker').empty().append('<option value="">-- Pilih Satker --</option>');
            $('#pegawais').empty().append('<option value="">-- Pilih Karyawan --</option>');

            if (kantorId) {
                $.get('/get-sat/' + kantorId, function (data) {
                    data.departemen.forEach(function (dept) {
                        $('#departemen').append('<option value="' + dept.id + '">' + dept.nama_dept + '</option>');
                    });
                });
            }
        });

     <?php endif; ?>

    // Load Pegawai saat Departemen dipilih
    $('#departemen').on('change', function () {
        let deptId = $(this).val();
        $('#satker').empty().append('<option value="">-- Pilih Satker --</option>');

        if (deptId) {
            $.get('/get-satker-by-departemen/' + deptId, function (data) {
                data.satker.forEach(function (sat) {
                    $('#satker').append('<option value="' + sat.id + '">' + sat.satuan_kerja + '</option>');
                });
            });
        }
    });
</script>
<script>
    $('#formRekap').on('submit', function(e) {
        const role = <?php echo e(Auth::user()->role); ?>;
        const kantor = $('#kantor').val();
        const departemen = $('#departemen').val();

        // Jika role 1 atau 0, wajib isi kantor dan departemen
        if ((role === 0 || role === 1)) {
            if (!kantor && !departemen) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Kantor dan Departemen kosong',
                    text: 'Silakan pilih kantor dan departemen terlebih dahulu.',
                });
                return false;
            }

            if (!kantor) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Kantor belum dipilih',
                    text: 'Silakan pilih kantor terlebih dahulu.',
                });
                return false;
            }

            if (!departemen) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Departemen belum dipilih',
                    text: 'Silakan pilih departemen terlebih dahulu.',
                });
                return false;
            }
        } else {
            if (!departemen) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Departemen belum dipilih',
                    text: 'Silakan pilih departemen terlebih dahulu.',
                });
                return false;
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.side.side', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/pegawai/rekap.blade.php ENDPATH**/ ?>