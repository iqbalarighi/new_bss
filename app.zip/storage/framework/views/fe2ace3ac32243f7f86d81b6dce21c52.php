<?php $__env->startSection('content'); ?>

<div class="container">

<?php if(Session::get('success')): ?>
<script type="text/javascript">
    Swal.fire({
  icon: "success",
  title: "<?php echo e(Session::get('success')); ?>",
  showConfirmButton: false,
  timer: 2000
});
</script>
<?php endif; ?>
    <div class="row justify-content-center">
        <div class="col mw-100">
            <div class="card">
                <div class="card-header d-flex justify-content-between fw-bold"><?php echo e(__('Daftar Pegawai')); ?>


        <a href="<?php echo e(route('pegawai.input')); ?>" class="btn btn-danger bi bi-person-add"></a>
                </div>

                <div class="card-body">
    <div class="card shadow-lg rounded-lg">
        <div class="card-body" style="overflow: auto;">
            <table class="table table-striped table-bordered table-hover"> 
                <thead class="table-dark text-center">
                    <tr>
                        <th>No.</th>
                        <th>NIP</th>
                        <th>Nama</th>
                        <?php if(Auth::user()->role == 0): ?>
                            <th>Perusahaan</th>
                        <?php endif; ?>
                        <?php if(Auth::user()->role == 1 || Auth::user()->role == 0): ?>
                            <th>Kantor</th>
                        <?php endif; ?>
                        <th>Departemen</th>
                        <th>Satker</th>
                        <th>Jabatan</th>
                        <th>Status</th>
                        <th>Shift</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawais->firstitem()+$num); ?></td>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawai->nip); ?></td>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawai->nama_lengkap); ?></td>
                        <?php if(Auth::user()->role == 0): ?>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawai->perusa->perusahaan); ?></td>
                        <?php endif; ?>
                        <?php if(Auth::user()->role == 1 || Auth::user()->role == 0): ?>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawai->kantor->nama_kantor); ?></td>
                        <?php endif; ?>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawai->deptmn->nama_dept); ?></td>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawai->sat->satuan_kerja); ?></td>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;white-space: wrap;"><?php echo e($pegawai->jabat->jabatan); ?></td>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawai->status); ?></td>
                            <td onclick="window.location='<?php echo e(route('pegawai.detail', $pegawai->id)); ?>'" style="cursor: pointer;"><?php echo e($pegawai->shifts->shift); ?></td>
                            <td class="align-middle text-center">
                                <button class="btn btn-primary btn-sm px-1" onclick="window.location='<?php echo e(route('pegawai.edit', $pegawai->id)); ?>'">Edit</button>
                                <button class="btn btn-danger btn-sm px-1">Hapus</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo e($pegawais->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
</div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.side.side', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/pegawai/index.blade.php ENDPATH**/ ?>