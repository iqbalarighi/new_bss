<!DOCTYPE html>
<html>
<head>
    <style>
        td, th { vertical-align: middle; text-align: center; }
        .info { text-align: left; }
    </style>
</head>
<body>
    <table>
        <tr>
            <td rowspan="5"><img src="<?php echo e(public_path('storage/img/logo.png')); ?>" height="80" /></td>
            <td colspan="7" style="text-align:center;"><b>LAPORAN PRESENSI KARYAWAN</b></td>
        </tr>
        <tr><td colspan="7" style="text-align:center;">PERIODE <?php echo e(\Carbon\Carbon::parse($periode)->isoFormat('MMMM YYYY')); ?></td></tr>
        <tr><td colspan="7" style="text-align:center;"><?php echo e($pegawai->perusa->perusahaan ?? '-'); ?></td></tr>
        <tr><td colspan="7" style="text-align:center;"><?php echo e($pegawai->perusa->alamat ?? '-'); ?></td></tr>
        <tr><td colspan="7" style="text-align:center;">-</td></tr>
    </table>

    <table>
        <tr>
            <td class="info">NIK : <?php echo e($pegawai->nip); ?></td>
        </tr>
        <tr>
            <td class="info">Nama Karyawan : <?php echo e(strtoupper($pegawai->nama_lengkap)); ?></td>
        </tr>
        <tr>
            <td class="info">Jabatan : <?php echo e($pegawai->jabat->jabatan ?? '-'); ?></td>
        </tr>
        <tr>
            <td class="info">Departemen : <?php echo e($pegawai->deptmn->nama_dept ?? '-'); ?></td>
        </tr>
        <tr>
            <td class="info">No. HP : <?php echo e($pegawai->no_hp); ?></td>
        </tr>
    </table>

    <table border="1" cellpadding="3">
        <thead>
            <tr>
                <th>No.</th>
                <th>Tanggal</th>
                <th>Jam Masuk</th>
                <th>Foto Masuk</th>
                <th>Jam Pulang</th>
                <th>Foto Pulang</th>
                <th>Keterangan</th>
                <th>Jumlah Jam Kerja</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $jamMasuk = \Carbon\Carbon::parse($a->jam_in);
                $jamStandar = \Carbon\Carbon::parse($a->shifts->jam_masuk);
                $terlambat = $jamMasuk->gt($jamStandar)
                    ? 'Terlambat ' . $jamMasuk->diff($jamStandar)->format('%h jam %i menit %s detik')
                    : 'Tepat waktu';

                $jamKerja = 'Belum absen pulang';
                if ($a->jam_out) {
                    $jamIn = \Carbon\Carbon::parse($a->tgl_absen . ' ' . $a->jam_in);
                    $jamOut = \Carbon\Carbon::parse($a->tgl_absen . ' ' . $a->jam_out);
                    if ($jamOut->lt($jamIn)) $jamOut->addDay();
                    $durasi = $jamOut->diff($jamIn);
                    $jamKerja = $durasi->format('%h jam %i menit %s detik');
                }
            ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e($a->tgl_absen); ?></td>
                <td style="color:<?php echo e($jamMasuk->gt($jamStandar) ? 'red' : 'black'); ?>"><?php echo e($a->jam_in); ?></td>
                <td align="center">
                    <?php if($a->foto_in): ?>
                        <img src="<?php echo e(public_path('storage/absensi/' . $a->pegawai->nip . '/' . $a->foto_in)); ?>" width="50">
                    <?php endif; ?>
                </td>
                <td><?php echo e($a->jam_out ?? '-'); ?></td>
                <td align="center">
                    <?php if($a->foto_out): ?>
                        <img src="<?php echo e(public_path('storage/absensi/' . $a->pegawai->nip . '/' . $a->foto_out)); ?>" width="50">
                    <?php else: ?>
                    -
                    <?php endif; ?>
                </td>
                <td><?php echo e($terlambat); ?></td>
                <td><?php echo e($jamKerja); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/pegawai/excelpreview.blade.php ENDPATH**/ ?>