<?php $__env->startSection('content'); ?>
<div class="container-xl mw-100">
    <div class="row g-2 align-items-center">
      <div class="col">
        <!-- Page pre-title -->
        <div class="page-pretitle">Dashboard</div>
        <h2 class="page-title">Data Pegawai</h2>
      </div>
    </div>
    <div class="row justify-content-center">
        <div class="row px-1">
            <div class="col-md-3 mb-2">
                <div class="card shadow-sm p-2">
                    <div class="card-body d-flex align-items-center" style="background-color: #e6f4ea; border-radius: 8px;">
                        <i class="bi bi-fingerprint text-success" style="font-size: 2rem; margin-right: 10px;"></i>
                        <div>
                            <h6 class="mb-0"><?php echo e($rekap->jmlhadir); ?></h6>
                            <small>Karyawan Hadir</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 mb-2">
                <div class="card shadow-sm p-2">
                    <div class="card-body d-flex align-items-center" style="background-color: #e6f0ff; border-radius: 8px;">
                        <i class="bi bi-file-earmark-text text-primary" style="font-size: 2rem; margin-right: 10px;"></i>
                        <div>
                            <h6 class="mb-0"><?php echo e($rekapizin->izin); ?></h6>
                            <small>Karyawan Izin</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 mb-2">
                <div class="card shadow-sm p-2">
                    <div class="card-body d-flex align-items-center" style="background-color: #fff4e6; border-radius: 8px;">
                        <i class="bi bi-emoji-frown text-warning" style="font-size: 2rem; margin-right: 10px;"></i>
                        <div>
                            <h6 class="mb-0"><?php echo e($rekapizin->sakit); ?></h6>
                            <small>Karyawan Sakit</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 mb-2">
                <div class="card shadow-sm p-2">
                    <div class="card-body d-flex align-items-center" style="background-color: #ffe6e6; border-radius: 8px;">
                        <i class="bi bi-alarm text-danger" style="font-size: 2rem; margin-right: 10px;"></i>
                        <div>
                            <h6 class="mb-0"><?php echo e($rekap->jmltelat); ?></h6>
                            <small>Karyawan Terlambat</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.side.side', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/home.blade.php ENDPATH**/ ?>