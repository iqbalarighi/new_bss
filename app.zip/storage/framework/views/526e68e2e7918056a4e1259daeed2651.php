<?php $__env->startSection('header'); ?>
<div class="appHeader text-light" style="background-color: #ef3b3b;">
    <div class="left">
        <a href="javascript:;" class="headerButton goBack">
            <ion-icon name="chevron-back-outline" class="ion-icon"></ion-icon>
        </a>
    </div>
    <div class="pageTitle">Izin</div>
    <div class="right"></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if(Session::get('success')): ?>
<script type="text/javascript">
    Swal.fire({
  icon: "success",
  title: "<?php echo e(Session::get('success')); ?>",
  showConfirmButton: true,
});
</script>
<?php endif; ?>

<?php if($cekizin == 0): ?>
<div class="fab-button bottom-right" style="margin-bottom: 70px;">
    <a href="<?php echo e(route('absen.formizin')); ?>" class="fab"><ion-icon name="add-outline"></ion-icon></a>
</div>
<?php else: ?>
<div class="fab-button bottom-right" style="margin-bottom: 70px;">
    <a href="#" class="fab" style="background-color: grey; color: white;">
        <ion-icon name="add-outline"></ion-icon>
    </a>
</div>
<?php endif; ?>
<div class="row" style="margin-top: 4rem;">
    <div class="col">
        <?php $__currentLoopData = $izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="listview image-listview">
            <li>
                <div class="item">
                    <div class="in">
                        <div>
                            <b><?php echo e(date("d-m-Y", strtotime($d->tanggal))); ?> (<?php echo e($d->jenis_izin == "s" ? "Sakit" : "Izin"); ?>)</b><br>
                            <small class="text-muted"><?php echo e($d->keterangan); ?></small>
                        </div>
                        <?php if($d->status_approve == 0): ?>
                        <span class="badge bg-warning">Waiting</span>
                        <?php elseif($d->status_approve == 1): ?>
                        <span class="badge bg-success">Approved</span>
                        <?php elseif($d->status_approve == 2): ?>
                        <span class="badge bg-danger">Decline</span>
                        <?php endif; ?>
                    </div>
                </div>
            </li>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.absen.absen', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/absen/izin.blade.php ENDPATH**/ ?>