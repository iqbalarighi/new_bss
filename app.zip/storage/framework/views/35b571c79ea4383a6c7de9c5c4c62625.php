<?php $__env->startSection('content'); ?>
<div class="container mt-1">
    <div class="card shadow-lg rounded-lg">

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

        <div class="card-header bg-danger text-white text-center fw-bold">Edit Pegawai
            <button class="float-right btn btn-sm btn-secondary" onclick="window.location.href='<?php echo e(route('pegawai.index')); ?>'">Kembali</button>
        </div>
        <div class="card-body">
<form method="POST" action="<?php echo e(route('pegawai.update', $pegawai->id)); ?>" enctype="multipart/form-data" id="formEditPegawai">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    
    <div class="mb-3">
        <label class="form-label">Nama Pegawai</label>
        <input type="text" class="form-control" name="nama" value="<?php echo e($pegawai->nama_lengkap); ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">NIP</label>
        <input type="text" class="form-control" name="nip" value="<?php echo e($pegawai->nip); ?>" readonly>
    </div>

    <div class="mb-3">
        <label class="form-label">Tanggal Lahir</label>
        <input type="date" class="form-control" name="tgl_lahir" value="<?php echo e($pegawai->tgl_lahir); ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Alamat</label>
        <textarea class="form-control" name="alamat" required><?php echo e($pegawai->alamat); ?></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">Alamat Domisili</label>
        <textarea class="form-control" name="alamat_domisili" required><?php echo e($pegawai->domisili); ?></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">No. Telepon</label>
        <input type="text" class="form-control" name="no_telepon" value="<?php echo e($pegawai->no_hp); ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">BPJS TK</label>
        <input type="text" class="form-control" name="bpjs_tk" value="<?php echo e($pegawai->bpjs_tk); ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">BPJS Kesehatan</label>
        <input type="text" class="form-control" name="bpjs_kesehatan" value="<?php echo e($pegawai->bpjs_sehat); ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Kontak Darurat</label>
        <input type="text" class="form-control" name="kontak_darurat" value="<?php echo e($pegawai->ko_drat); ?>" required>
    </div>

    <?php if(Auth::user()->role === 0): ?>
    <div class="mb-3">
        <label class="form-label">Perusahaan</label>
        <select name="perusahaan" class="form-select" required>
            <option selected disabled value="">Pilih Perusahaan</option>
            <?php $__currentLoopData = $tenant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($pegawai->perusahaan == $item->id ? 'selected' : ''); ?>><?php echo e($item->perusahaan); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php endif; ?>

    <?php if(Auth::user()->role === 0 || Auth::user()->role === 1): ?>
    <div class="mb-3">
        <label class="form-label">Penempatan Kerja</label>
        <select name="kantor" class="form-select" required>
            <?php $__currentLoopData = $kantorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($pegawai->nama_kantor == $item->id ? 'selected' : ''); ?>><?php echo e($item->nama_kantor); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php endif; ?>

    <div class="mb-3">
        <label class="form-label">Departemen</label>
        <select name="dept" class="form-select" required>
            <?php $__currentLoopData = $departemenList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($pegawai->dept == $item->id ? 'selected' : ''); ?>><?php echo e($item->nama_dept); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Satuan Kerja</label>
        <select name="satker" class="form-select" required>
            <?php $__currentLoopData = $satkerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($pegawai->satker == $item->id ? 'selected' : ''); ?>><?php echo e($item->satuan_kerja); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Jabatan</label>
        <select name="jabatan" class="form-select" required>
            <?php $__currentLoopData = $jabatanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($pegawai->jabatan == $item->id ? 'selected' : ''); ?>><?php echo e($item->jabatan); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Shift</label>
        <select name="shift" class="form-select" required>
            <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($pegawai->shift == $item->id ? 'selected' : ''); ?>><?php echo e($item->shift); ?> <?php echo e(Carbon\Carbon::parse($item->jam_masuk)->format('H:i')); ?>-<?php echo e(Carbon\Carbon::parse($item->jam_keluar)->format('H:i')); ?> WIB</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Status Pegawai</label>
        <select name="status" class="form-select" required>
            <option value="Aktif" <?php echo e($pegawai->status == 'Aktif' ? 'selected' : ''); ?>>Aktif</option>
            <option value="Tidak Aktif" <?php echo e($pegawai->status == 'Tidak Aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Foto</label>
        <input type="file" class="form-control" name="foto" accept=".jpg,.jpeg,.png">
        <?php if($pegawai->foto): ?>
        <small class="form-text text-muted">
            Foto saat ini: 
            <a href="#" class="lihat-foto" data-img="<?php echo e(asset('storage/foto_pegawai/'.$pegawai->nip.'/'.$pegawai->foto)); ?>">Lihat</a>
        </small>
        <?php endif; ?>
    </div>

    <div class="text-center">
        <button type="submit" class="btn btn-primary">Perbarui</button>
    </div>
</form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    document.getElementById('formEditPegawai').addEventListener('submit', function(e) {
        e.preventDefault(); // Stop form dari langsung submit

        Swal.fire({
            title: 'Perbarui Data?',
            text: "Perubahan ini akan memengaruhi data terkait. Lanjutkan?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, perbarui!',
            cancelButtonText: 'Batal',
            allowOutsideClick: false,
            reverseButtons: true,
            allowEscapeKey: false,
        }).then((result) => {
            if (result.isConfirmed) {
                // Tampilkan loading dalam SweetAlert
                Swal.fire({
                    title: 'Memproses...',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                // Submit form setelah loading muncul
                e.target.submit();
            }
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const lihatFotoBtn = document.querySelector('.lihat-foto');

        if (lihatFotoBtn) {
            lihatFotoBtn.addEventListener('click', function (e) {
                e.preventDefault();
                const imgSrc = this.getAttribute('data-img');

                Swal.fire({
                    imageUrl: imgSrc,
                    imageAlt: 'Foto Pegawai',
                    showCloseButton: true,
                    showConfirmButton: false,
                    width: 400
                });
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.side.side', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/pegawai/edit.blade.php ENDPATH**/ ?>