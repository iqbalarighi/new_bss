<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col mw-100">
            <div class="card">
                <div class="card-header fw-bold"><?php echo e(__('Data Pegawai')); ?>

                    <button class="btn btn-sm btn-secondary float-end" onclick="history.back();">Kembali</button>
                </div>

                <div class="card-body">
                    
<div class="row d-flex justify-content-around">
            <div class="col-md-4 text-center mb-2">
                <div class="card p-3">
                    <h5>Foto Pegawai</h5>
                    <div id="foto-container">
                        <!-- Jika foto tersedia -->
                        <?php if($detail->foto != null): ?>
                        <img id="fotoPegawai" src="<?php echo e(asset('storage/foto_pegawai/'.$detail->nip.'/'.$detail->foto)); ?>" alt="Foto Pegawai" class="img-fluid rounded" style="max-height: 200px;">
                        <button class="btn btn-warning mt-2">Ganti Foto</button>
                        <?php else: ?>
                        <!-- Jika foto tidak tersedia -->
                         <input type="file" class="form-control mt-2">
                         <button class="btn btn-primary mt-2">Upload Foto</button>
                         <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr><th>Nama</th><td><?php echo e($detail->nama_lengkap); ?></td></tr>
                    <tr><th>NIP</th><td><?php echo e($detail->nip); ?></td></tr>
                    <tr><th>Ubah Password</th><td><button class="btn btn-secondary" onclick="ubahPassword()">Ubah</button></td></tr>
                    <tr><th>Tanggal Lahir</th><td><?php echo e(Carbon\Carbon::parse($detail->tgl_lahir)->locale('id')->isoFormat('D MMMM Y')); ?></td></tr>
                    <tr><th>Alamat</th><td><?php echo e($detail->alamat); ?></td></tr>
                    <tr><th>Alamat Domisili</th><td><?php echo e($detail->domisili); ?></td></tr>
                    <tr><th>No Telepon</th><td><?php echo e($detail->no_hp); ?></td></tr>
                    <tr><th>BPJS TK</th><td><?php echo e($detail->bpjs_tk); ?></td></tr>
                    <tr><th>BPJS Kesehatan</th><td><?php echo e($detail->bpjs_sehat); ?></td></tr>
                    <tr><th>Kontak Darurat</th><td><?php echo e($detail->ko_drat); ?></td></tr>
                    
                    <tr><th>Unit Kerja</th><td><?php echo e($detail->kantor->nama_kantor); ?></td></tr>
                    <tr><th>Satuan Kerja</th><td><?php echo e($detail->sat->satuan_kerja); ?></td></tr>
                    <tr><th>Posisi</th><td><?php echo e($detail->jabat->jabatan); ?></td></tr>
                    <tr><th>Status Pegawai</th><td>Kontrak</td></tr>
                </table>
            </div>
        </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function ubahPassword() {
        Swal.fire({
            title: 'Ubah Password',
            input: 'password',
            inputLabel: 'Masukkan Password Baru',
            inputPlaceholder: 'Password baru',
            inputAttributes: {
                minlength: 6,
                autocapitalize: 'off',
                autocorrect: 'off'
            },
            showCancelButton: true,
            confirmButtonText: 'Simpan',
            cancelButtonText: 'Batal',
            preConfirm: (password) => {
                if (!password) {
                    Swal.showValidationMessage('Password tidak boleh kosong');
                } else {
                    // Kirim password ke server

                    return fetch('<?php echo e(route('pegawai.upass')); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({ 
                        password, 
                        pegawai_id: "<?php echo e($detail->id); ?>" 
                    })
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(response.statusText);
                        }
                        return response.json();
                    })
                    .catch(error => {
                        Swal.showValidationMessage(`Request failed: ${error}`);
                    });
                }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire('Berhasil!', 'Password telah diperbarui.', 'success');
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.side.side', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/pegawai/detail.blade.php ENDPATH**/ ?>