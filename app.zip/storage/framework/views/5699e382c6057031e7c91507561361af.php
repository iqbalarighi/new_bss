<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col mw-100">
            <div class="card">
                <div class="card-header d-flex justify-content-between fw-bold"><?php echo e(__('Daftar Izin Pegawai')); ?>

                </div>

                <div class="card-body">
                   <table class="table table-bordered table-striped">
        <thead class="table-dark text-center">
            <tr>
                <th>No</th>
                <?php if(Auth::user()->role == 0): ?>
                <th>Perusahaan</th>
                <?php endif; ?>
                <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
                <th>Kantor</th>
                <?php endif; ?>
                <th>NIP</th>
                <th>Nama Pegawai</th>
                <th>Tanggal</th>
                <th>Jenis Izin</th>
                <th>Keterangan</th>
                <th>Foto</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $izinList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($izinList->firstitem() + $num); ?></td>
                <?php if(Auth::user()->role == 0): ?>
                <td><?php echo e($izin->perusa->perusahaan ?? '-'); ?></td>
                <?php endif; ?>
                <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
                <td><?php echo e($izin->kantor->nama_kantor ?? '-'); ?></td>
                <?php endif; ?>
                <td><?php echo e($izin->pegawai->nip); ?></td>
                <td><?php echo e($izin->pegawai->nama_lengkap ?? '-'); ?></td>
                <td><?php echo e($izin->tanggal); ?></td>
                <td>
                    <?php switch($izin->jenis_izin):
                        case ('s'): ?> Sakit <?php break; ?>
                        <?php case ('i'): ?> Izin <?php break; ?>
                        <?php case ('c'): ?> Cuti <?php break; ?>
                        <?php default: ?> -
                    <?php endswitch; ?>
                </td>
                <td><?php echo e($izin->keterangan); ?></td>
                <td>
                    <?php if($izin->foto): ?>
                        <a href="#" class="lihat-foto" data-img="<?php echo e(asset('storage/bukti_izin/'.$izin->pegawai->nip.'/'.$izin->foto)); ?>">
                            <img src="<?php echo e(asset('storage/bukti_izin/'.$izin->pegawai->nip.'/'.$izin->foto)); ?>" alt="Thumbnail" width="40" height="40" class="rounded">
                        </a>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($izin->status_approve == 1): ?>
                        <a href="#" class="badge bg-success approve-popup" data-id="<?php echo e($izin->id); ?>">Disetujui</a>
                    <?php elseif($izin->status_approve == 2): ?>
                       <a href="#" class="badge bg-danger approve-popup" data-id="<?php echo e($izin->id); ?>">Ditolak</a>
                    <?php else: ?>
                        <a href="#" class="badge bg-warning text-dark approve-popup" data-id="<?php echo e($izin->id); ?>">Menunggu</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
$(document).ready(function() {
    $('.lihat-foto').on('click', function(e) {
        e.preventDefault();
        const imgUrl = $(this).data('img');
        Swal.fire({
            imageUrl: imgUrl,
            imageWidth: 500,
            imageAlt: 'Foto Izin',
            confirmButtonText: 'Tutup',
        });
    });
});


$('.approve-popup').on('click', function(e) {
        e.preventDefault();
        const id = $(this).data('id');

        Swal.fire({
            title: 'Status Izin',
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: 'Diterima',
            confirmButtonColor: 'green',
            denyButtonText: 'Ditolak',
            cancelButtonText: 'Batal'
        }).then((result) => {
            let status = null;
            if (result.isConfirmed) {
                status = 1;
            } else if (result.isDenied) {
                status = 2;
            }

            if (status !== null) {
                $.ajax({
                    url: `/pegawai/absensi/izin/${id}/status`,
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        status_approve: status
                    },
                    success: function(response) {
                        Swal.fire('Berhasil!', response.message, 'success').then(() => {
                            location.reload();
                        });
                    },
                    error: function(xhr) {
                        Swal.fire('Gagal', 'Terjadi kesalahan saat memproses.', 'error');
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.side.side', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/pegawai/izin.blade.php ENDPATH**/ ?>