<?php
    use Carbon\Carbon;
    use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

    $tanggalAwal = Carbon::createFromDate($tahun, $bulan, 1);
    $jumlahHari = $tanggalAwal->daysInMonth;
    $totalKolom = ($satker == null ? 4 : 3) + $jumlahHari + 1; // sesuai controller
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body {
            font-size: 10px;
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }
        th, td {
            border: 1px solid #000;
            padding: 2px;
            text-align: center;
        }
        th {
            background-color: #f0f0f0;
        }
        .text-start {
            text-align: left;
        }
        .red {
            color: red;
          }
    </style>
</head>
<body>
    <table>
        <tr><td colspan="<?php echo e($totalKolom); ?>" style="text-align:center;"><strong>Rekap Absensi Bulanan</strong></td></tr>
        <tr><td colspan="<?php echo e($totalKolom); ?>" style="text-align:center;"><strong>Departemen: <?php echo e($depar->nama_dept); ?></strong></td></tr>
         <?php if($satker != null): ?>
        <tr><td colspan="<?php echo e($totalKolom); ?>" style="text-align:center;"><strong>Satker: <?php echo e($sat->satuan_kerja); ?></strong></td></tr>
        <?php endif; ?>
        <tr><td colspan="<?php echo e($totalKolom); ?>" style="text-align:center;">
            <strong>Periode: <?php echo e(Carbon::parse($periode)->isoFormat('MMMM YYYY')); ?></strong>
        </td></tr>
    </table>

    <table>
        <thead>
            <tr>
                <th rowspan="2">No</th>
                <th rowspan="2">NIP</th>
                <th rowspan="2">Nama</th>
                <?php if($satker == null): ?>
                    <th rowspan="2">Satker</th>
                <?php endif; ?>
                <th colspan="<?php echo e($jumlahHari); ?>">Tanggal</th>
                <th rowspan="2">THE</th>
            </tr>
            <tr>
                <?php for($i = 1; $i <= $jumlahHari; $i++): ?>
                    <th><?php echo e($i); ?></th>
                <?php endfor; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($r['nip']); ?></td>
                    <td class="text-start"><?php echo e($r['nama']); ?></td>
                    <?php if($satker == null): ?>
                        <td class="text-start"><?php echo e($r['sat']); ?></td>
                    <?php endif; ?>
                    <?php for($i = 1; $i <= $jumlahHari; $i++): ?>
                        <?php
                            $tgl = Carbon::createFromDate($tahun, $bulan, $i)->toDateString();
                            $absen = $r['absensi']->firstWhere('tgl_absen', $tgl);
                            $izin = $r['izin']->firstWhere('tanggal', $tgl);
                        ?>
                        <td>
                            <?php if($absen): ?>
                                
                                <span class="<?php echo e($absen->jam_in > $absen->shifts->jam_masuk ? 'red' : ''); ?>"><?php echo e($absen->jam_in ?? ''); ?></span><br>
                                <span class="<?php echo e($absen->jam_out ?? 'red'); ?>"><?php echo e($absen->jam_out ?? '00:00:00'); ?></span>
                            <?php elseif($izin): ?>
                                <?php if(Str::contains(strtolower($izin->jenis_izin), 's')): ?>
                                    S
                                <?php elseif(Str::contains(strtolower($izin->jenis_izin), 'i')): ?>
                                    I
                                <?php else: ?>
                                    C
                                <?php endif; ?>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    <?php endfor; ?>
                    <td><?php echo e($r['absensi']->count() + $r['izin']->count()); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/pegawai/excel.blade.php ENDPATH**/ ?>