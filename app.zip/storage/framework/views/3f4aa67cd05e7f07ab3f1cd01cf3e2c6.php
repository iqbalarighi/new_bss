<?php $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $abs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($absen->firstitem() + $key); ?></td>
                                <td class="text-center"><?php echo e($abs->pegawai->nip); ?></td>
                                <td><?php echo e($abs->pegawai->nama_lengkap); ?></td>
                                <td><?php echo e($abs->shifts->shift); ?></td>
<?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?><td><?php echo e($abs->pegawai->kantor->nama_kantor); ?></td> <?php endif; ?>
                                <td><?php echo e($abs->pegawai->deptmn->nama_dept); ?></td>
                                <td><?php echo e($abs->pegawai->sat->satuan_kerja); ?></td>
                                <td class="text-center <?php echo e($abs->jam_in > $abs->shifts->jam_masuk ? 'text-danger' : ''); ?>"><?php echo e($abs->jam_in); ?></td>
                                <td class="text-center"> 
                                    <img src="<?php echo e(asset('storage/absensi/'.$abs->pegawai->nip.'/'.$abs->foto_in)); ?>" width="40px">
                                </td>
                                <td class="text-center"><?php echo e($abs->jam_out == null ? 'Belum Absen Pulang' : $abs->jam_out); ?></td>
                                <td class="text-center">
                                    <?php if($abs->foto_out == null): ?>
                                    <i class="bi bi-hourglass-split"></i>
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('storage/absensi/'.$abs->pegawai->nip.'/'.$abs->foto_out)); ?>" width="40px">
                                    <?php endif; ?>
                                </td>
                                <td class="text-center <?php echo e($abs->jam_in > $abs->shifts->jam_masuk ? 'text-danger' : ''); ?>">
                                    <?php
                                        $jamStandar = Carbon\Carbon::parse($abs->shifts->jam_masuk);

                                    $jamAktual = Carbon\Carbon::parse($abs->jam_in); // misalnya: '08:23'

                                    if ($jamAktual->gt($jamStandar)) {
                                        $selisih = $jamAktual->diff($jamStandar);
    echo "Terlambat " . ($selisih->h == 0 ? '' : $selisih->h . ' jam ') . ($selisih->i == 0 ? '' : $selisih->i . ' menit ') . $selisih->s . ' detik';
                                    } else {
                                        echo "Tepat waktu";
                                    }
                                    ?>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-primary" 
                                    data-id="<?php echo e($abs->id); ?>" 
                                    data-lokasi="<?php echo e($abs->lokasi_in); ?>" 
                                    data-nama="<?php echo e($abs->pegawai->nama_lengkap); ?>" 
                                    data-kantor="<?php echo e($abs->pegawai->kantor->lokasi); ?>" 
                                    data-radius="<?php echo e($abs->pegawai->kantor->radius); ?>" 
                                    id="btnMap"><i class="bi bi-map"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/pegawai/getabsensi.blade.php ENDPATH**/ ?>