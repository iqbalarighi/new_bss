<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col mw-100">
            <div class="card">
                <div class="card-header"><?php echo e(__('Daftar Satuan Kerja')); ?>

                    <button class="btn btn-sm btn-primary float-right" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="bi bi-building-add"></i></button>
                </div>

<?php if(Session::get('status')): ?>
<script>
        Swal.fire({
          title: "Berhasil",
          icon: "success",
          showConfirmButton: false,
          timer: 1500
        });
</script>
<?php endif; ?>

<style>
        .modal.fade .modal-dialog {
            transform: scale(0.8);
            transition: transform 0.3s ease-out;
        }
        .modal.show .modal-dialog {
            transform: scale(1);
        }

        th {
            text-align: center;
            vertical-align: middle;
        }
    </style>
    <!-- Modal Tambah Bootstrap -->                    
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered animate__animated animate__zoomIn">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Satuan Kerja</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="/satker/tambah" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="satker" class="form-label">Satuan Kerja</label>
                        <input type="text" class="form-control" id="satker" name="satker" placeholder="Satuan Kerja" required>
                    </div>
                    <?php if(Auth::user()->role == 0): ?>
                    <div class="mb-3">
                        <label for="tenantName" class="form-label">Nama Perusahaan</label>
                        <select name="perusahaan" id="tenantName" class="form-select" required>
                            <option selected disabled value="">Pilih Perusahaan</option>
                            <?php $__currentLoopData = $perusahaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usaha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($usaha->id); ?>"><?php echo e($usaha->perusahaan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                   <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
                    <div class="mb-3">
                        <label for="kantor" class="form-label">Kantor</label>
                        <select name="kantor" id="kantor" class="form-select" required>
                            <option selected disabled value="">Pilih Kantor</option>
                            <?php $__currentLoopData = $kantor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($office->id); ?>"><?php echo e($office->nama_kantor); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                     <?php endif; ?>
                    <div class="mb-3">
                        <label for="departemen" class="form-label">Departemen</label>
                        <select name="departemen" id="departemen" class="form-select" required>
                            <option selected disabled value="">Pilih Departemen</option>
                            <?php $__currentLoopData = $departemen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->nama_dept); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                   
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div> 
        </form>
        </div>
    </div>
</div>
    <!-- Modal Edit Bootstrap -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered animate__animated animate__zoomIn">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Satuan Kerja</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editForm" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" id="edit_id" name="id">
                        <div class="mb-3">
                            <label for="edit_satker" class="form-label">Satuan Kerja</label>
                            <input type="text" class="form-control" id="edit_satker" name="satker" required>
                        </div>

                        <?php if(Auth::user()->role == 0): ?>
                        <div class="mb-3">
                            <label for="edit_tenantName" class="form-label">Nama Perusahaan</label>
                            <select name="perusahaan" id="edit_tenantName" class="form-select" required>
                                <option selected disabled value="">Pilih Perusahaan</option>
                                <?php $__currentLoopData = $perusahaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usaha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($usaha->id); ?>"><?php echo e($usaha->perusahaan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php endif; ?>
                       
                     <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
                    <div class="mb-3">
                        <label for="edit_kantor" class="form-label">Kantor</label>
                        <select name="kantor" id="edit_kantor" class="form-select" required>
                            <option selected value="">Pilih Kantor</option>
                            <?php $__currentLoopData = $kantor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($office->id); ?>"><?php echo e($office->nama_kantor); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
                        <div class="mb-3">
                        <label for="edit_departemen" class="form-label">Departemen</label>
                        
                        <select name="departemen" id="edit_departemen" class="form-select" required>
                            <option selected value="">Pilih Departemen</option>
                            <?php $__currentLoopData = $departemen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->nama_dept); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php else: ?> 
                    <div class="mb-3">
                        <label for="edit_departemen" class="form-label">Departemen</label>
                        <select name="departemen" id="edit_departemen" class="form-select" required>
                            <option selected value="">Pilih Departemen</option>
                            <?php $__currentLoopData = $departemen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->nama_dept); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div> 
            </form>
            </div>
        </div>
    </div>
    <!-- Modal Edit Bootstrap -->

    
        <div class="card-body" style="overflow: auto;"> 
            <table class="table table-striped table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Satuan Kerja</th>
                <?php if(Auth::user()->role == 0): ?>       
                    <th>Perusahaan</th>
                <?php endif; ?>
                <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
                    <th>Kantor</th>
                <?php endif; ?>
                    <th>Departemen</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $satker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="row-<?php echo e($ker->id); ?>">
                    <td class="align-middle text-center"><?php echo e($satker->firstitem()+$key); ?></td>
                    <td><?php echo e($ker->satuan_kerja); ?></td>
                 <?php if(Auth::user()->role == 0): ?>
                    <td><?php echo e($ker->perusa->perusahaan); ?></td>
                <?php endif; ?> 
                <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
                    <td><?php echo e($ker->kantor == 0 ? '-' : $ker->kant->nama_kantor); ?></td>
                <?php endif; ?>
                    <td><?php echo e($ker->dept_id == 0 ? '-' : $ker->deptmn->nama_dept); ?></td>
                    <td class="align-middle text-center">
                        <button class="btn btn-primary btn-sm cen edit-btn" 
                        data-id="<?php echo e($ker->id); ?>" 
                        data-satker="<?php echo e($ker->satuan_kerja); ?>" 
                        data-departemen="<?php echo e($ker->dept_id); ?>"
                    <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
                        data-kantor="<?php echo e($ker->kantor); ?>" 
                    <?php else: ?>
                        data-kantor="<?php echo e(Auth::user()->kantor); ?>" 
                    <?php endif; ?>
                    <?php if(Auth::user()->role == 0): ?> 
                        data-perusahaan="<?php echo e($ker->perusahaan); ?>" 
                    <?php endif; ?>>Edit</button>
                        <button class="btn btn-danger btn-sm cen delete-btn" data-id="<?php echo e($ker->id); ?>">Hapus</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
         <div class="d-flex justify-content-center">
                <?php echo e($satker->links('pagination::bootstrap-5')); ?>

            </div>
    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    // Dynamic load departemen berdasarkan kantor saat tambah
    $('#kantor').change(function () {
        let kantorId = $(this).val();
        if (kantorId) {
            $.get(`/get-sat/${kantorId}`, function (response) {
                let options = '<option value="">Pilih Departemen</option>';
                response.departemen.forEach(dept => {
                    options += `<option value="${dept.id}">${dept.nama_dept}</option>`;
                });
                $('#departemen').html(options);
            });
        } else {
            $('#departemen').html('<option value="">Pilih Departemen</option>');
        }
    });

    // Dynamic load departemen saat modal edit dibuka
    $('#edit_kantor').on('change', function () {
        let kantorId = $(this).val();
        if (kantorId) {
            $.get(`/get-sat/${kantorId}`, function (response) {
                let options = '<option value="">Pilih Departemen</option>';
                response.departemen.forEach(dept => {
                    options += `<option value="${dept.id}" ${dept.id == departemen ? 'selected' : ''}>${dept.nama_dept}</option>`;
                });
                $('#edit_departemen').html(options);


            });
        }
    });

</script>
<script>
$(document).ready(function () {
    // Saat tombol edit diklik
    $(document).on("click", ".edit-btn", function () {
        let btn = $(this);
        let id = btn.data("id");
        let perusahaan = btn.data("perusahaan");
        let kantor = btn.data("kantor");
        let departemen = btn.data("departemen");
        let satker = btn.data("satker");

        $("#edit_id").val(id);
        $("#edit_departemen").html('<option value="">Loading...</option>');
        $("#edit_satker").val(satker);

        <?php if(Auth::user()->role == 0): ?>
            $("#edit_tenantName").val(perusahaan);
        <?php endif; ?>
        <?php if(Auth::user()->role == 0 || Auth::user()->role == 1): ?>
            $("#edit_kantor").val(kantor);
        <?php endif; ?>

        $("#editForm").attr("action", "/satker/edit/" + id);
<?php if(Auth::user()->role == 0): ?>
        if (perusahaan) {
            $.getJSON('/get-konten/' + perusahaan, function (response) {
<?php else: ?> 
        if (kantor) {
            $.getJSON('/get-sat/' + kantor, function (response) {
<?php endif; ?>
                let departemenOptions = '<option value="">Pilih Departemen</option>';

            <?php if(Auth::user()->role == 0): ?>
                $.each(response.depts, function (i, dept) {
            <?php else: ?>
                $.each(response.departemen, function (i, dept) {
            <?php endif; ?>
                    departemenOptions += `<option value="${dept.id}" ${dept.id == departemen ? 'selected' : ''}>${dept.nama_dept}</option>`;
                });

                $("#edit_departemen").html(departemenOptions);
            });
        }

        $("#editModal").modal("show");
    });

    // Submit form edit dengan konfirmasi
    $("#editForm").on("submit", function (e) {
        e.preventDefault();
        Swal.fire({
            title: "Konfirmasi Perubahan",
            text: "Perubahan ini akan mempengaruhi data terkait. Lanjutkan?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Ya, update!",
            cancelButtonText: "Batal"
        }).then((result) => {
            if (result.isConfirmed) {
                e.target.submit();
            }
        });
    });
});
</script>

<script>
document.querySelectorAll(".delete-btn").forEach(button => {
            button.addEventListener("click", function () {
                let id = this.getAttribute("data-id");
                Swal.fire({
                    title: "Apakah Anda yakin?",
                    text: "Data yang dihapus tidak dapat dikembalikan!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#d33",
                    cancelButtonColor: "#3085d6",
                    confirmButtonText: "Ya, hapus!",

                }).then((result) => {
                    if (result.isConfirmed) {
                        Swal.fire({
                            title: "Menghapus...",
                            text: "Mohon tunggu",
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });
                        fetch("/satker/hapus/" + id, {
                            method: "DELETE",
                            headers: {
                                "X-CSRF-TOKEN": '<?php echo e(csrf_token()); ?>'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire("Terhapus!", data.message, "success");
                                document.getElementById("row-" + id).remove();
                            } else {
                                Swal.fire("Gagal!", data.message, "error");
                            }
                        })
                        .catch(error => {
                            Swal.fire("Error!", "Gagal menghapus data.", "error");
                        });
                    }
                });
            });
        });
</script>

<script>
    $(document).ready(function() {
        $('#kantor').change(function() {
            let perusahaanId = $(this).val();
            if (perusahaanId) {
                $.ajax({
                    url: '/get-sat/' + perusahaanId,
                    type: 'GET',
                    success: function(response) {
                        let departemenOptions = '<option value="">Pilih Departemen</option>';
                        let satkerOptions = '<option value="">Pilih Satuan Kerja</option>';

                        response.departemen.forEach(function(dept) {
                            departemenOptions += `<option value="${dept.id}" ${dept.id == departemen ? 'selected' : ''}>${dept.nama_dept}</option>`;
                        });
                        response.satker.forEach(function(satker) {
                            satkerOptions += `<option value="${satker.id}">${satker.nama_satker}</option>`;
                        });

                        $('#departemen').html(departemenOptions);
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
            } else {
                $('#departemen').empty().append('<option value="">Pilih Departemen</option>');
            }
        });
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.side.side', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/master/satker.blade.php ENDPATH**/ ?>