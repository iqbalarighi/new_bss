<?php $__env->startSection('header'); ?>
<div class="appHeader text-light" style="background-color: #ef3b3b;">
    <div class="left">
        <a href="javascript:;" class="headerButton goBack">
            <ion-icon name="chevron-back-outline" class="ion-icon"></ion-icon>
        </a>
    </div>
    <div class="pageTitle">Histori</div>
    <div class="right"></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top:70px">
    <div class="col">
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <input type="month" id="bultah" min="2024-01" max="<?php echo e(Carbon\Carbon::now()->format('Y-m')); ?>" class="form-control" value="<?php echo e(Carbon\Carbon::now()->isoFormat('YYYY-MM')); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                	<button class="btn btn-sm btn-primary btn-block btn-hover" id="getdata">
                		<ion-icon name="search-outline"></ion-icon> Cari
                	</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12" id="tampilhistori">
        
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function() {
        $("#getdata").click(function(e) {
            var bultah = $("#bultah").val();
            $.ajax({
                type: 'POST',
                url: '/absen/gethistori',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    bultah: bultah
                },
                cache: false,
                success: function(respond) {
                    $("#tampilhistori").html(respond);
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.absen.absen', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_Pengamanan\web\new_bss\resources\views/absen/histori.blade.php ENDPATH**/ ?>